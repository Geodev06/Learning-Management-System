<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    @include('core.core_css')

    @livewireStyles
</head>

<body>
    <livewire:forms.registration />
</body>
@include('core.core_js')
@livewireScripts


</html>