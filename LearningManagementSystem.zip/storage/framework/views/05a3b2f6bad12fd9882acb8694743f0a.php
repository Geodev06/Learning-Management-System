<div class="alert alert-<?php echo e($type); ?> alert-dismissible fade show" role="alert">
    <strong><?php echo e($title ??''); ?> </strong> <br> <span class="font-12"><?php echo e($message ?? ''); ?></span>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div><?php /**PATH C:\Users\Administrator\Desktop\LearningManagementSystem\resources\views/components/alert.blade.php ENDPATH**/ ?>