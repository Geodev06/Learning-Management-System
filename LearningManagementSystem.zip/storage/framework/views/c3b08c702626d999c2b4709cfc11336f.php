<div class="container">
    <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve(['title' => 'Error','message' => ''.e(session('error')).'','type' => 'danger'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="row">
        <div class="col-lg-12 p-2">
            <form class="forms-sample material-form">

                <h5> Delete <?php echo e($title ?? ''); ?> </h5>
                <p>
                    Are you sure you want to delete this item? This action cannot be undone.
                </p>


                <div class="button-container float-end mx-2">
                    <button type="button"
                        class="btn btn-rounded btn-danger"
                        wire:click="submit()"
                        wire:loading.attr="disabled">
                        <span wire:loading.remove>Yes, Delete</span>
                        <span wire:loading>
                            <i class="fa fa-spinner fa-spin"></i> Loading...
                        </span>
                    </button>
                </div>

            </form>
        </div>
    </div>


        <?php
        $__assetKey = '1645365244-0';

        ob_start();
    ?>
    <script src="<?php echo e(asset('assets/js/sweetalert2.all.min.js')); ?>"></script>
        <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;
            \Livewire\store($this)->push('assets', $__output, $__assetKey);
        }
    ?>

        <?php
        $__scriptKey = '1645365244-1';
        ob_start();
    ?>
    <script>
        $wire.on('close_modal', (data) => {


            Swal.fire({
                title: data[0].title,
                text: data[0].message,
                icon: data[0].status
            });

            $('#delete_modal').modal('hide')


        })
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div><?php /**PATH C:\Users\Administrator\Desktop\LearningManagementSystem\resources\views/livewire/components/deleteprompt.blade.php ENDPATH**/ ?>