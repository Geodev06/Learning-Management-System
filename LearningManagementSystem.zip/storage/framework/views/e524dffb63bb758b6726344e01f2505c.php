<div class="container-fluid p-0">
    <div class="row no-gutters h-100">
        <div class="col-lg-6 p-0"
            style="background: url('https://www.businessinsider.in/photo/53672539/This-is-what-makes-Simplilearn-one-of-the-most-effective-Education-Startups-in-recent-times.jpg'); background-size:cover;">
        </div>

        <div class="col-lg-6 p-0">
            <div class="card" style="min-height: 100vh; padding:10%">
                <div class="card-body mt-5 py-5">
                    <h3 class="text-primary">Learning Management System</h3>
                    <p class="card-description"> Please login to continue </p>

                    <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
                    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve(['title' => 'Error','message' => ''.e(session('error')).'','type' => 'danger'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <form class="forms-sample material-form">
                        <div class="form-group">
                            <input type="text" required="required" wire:model="email"  class="<?php if($errors->has('email')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" autocomplete="off">
                            <label for="input" class="control-label">Email address</label><i class="bar"></i>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        </div>
                        <div class="form-group">
                            <input type="password" required="required" wire:model="password" class="<?php if($errors->has('email')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" autocomplete="off">
                            <label for="input" class="control-label">Password</label><i class="bar"></i>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        </div>

                        <div class="my-2 d-flex justify-content-between align-items-center">
                            <div class="form-check">
                                <label class="form-check-label text-muted">
                                    <input type="checkbox" class="form-check-input"> Keep me signed in <i class="input-helper"></i></label>
                            </div>
                            <a href="#" class="auth-link text-black" style="font-size: small;">Forgot password?</a>
                        </div>
                        <div class="button-container">
                            <button type="button"
                                class="btn btn-rounded btn-primary"
                                wire:click="submit"
                                wire:loading.attr="disabled">
                                <span wire:loading.remove>Sign up</span>
                                <span wire:loading>
                                    <i class="fa fa-spinner fa-spin"></i> Loading...
                                </span>
                            </button>
                        </div>
                        <div style="font-size: small;" class="text-left mt-4 fw-light"> Don't have an account? <a href="<?php echo e(route('register')); ?> " wire:navigate class="text-primary">Create</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Administrator\Desktop\LearningManagementSystem\resources\views/livewire/forms/login.blade.php ENDPATH**/ ?>