<div class="row">
    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-sm-12 col-md-6 col-lg-3 mb-2">

        <div class="card">

            <div class="card-body d-flex flex-column">
                <div class="d-flex justify-content-between">
                    <h4><?php echo e($module->title); ?></h4>
                    <div class="d-flex justify-content-between">
                        <!--[if BLOCK]><![endif]--><?php if($module->post_flag == 'Y'): ?>
                        <i class="fa fa-folder text-primary cursor-pointer" data-bs-toggle="tooltip" title="Manage"></i>
                        <?php else: ?>
                        <i class="fa fa-pencil text-primary mx-2 cursor-pointer"
                         wire:click="$dispatch('show-modal', { id: <?php echo e($module->id); ?>, action : 'Edit' })"
                         data-bs-toggle="tooltip" title="Edit"></i>
                        <i class="fa fa-trash-o text-danger cursor-pointer"
                         wire:click="$dispatch('show-delete-modal', { id: <?php echo e($module->id); ?> })"
                         data-bs-toggle="tooltip" title="Delete"></i>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <p class="font-12"><?php echo e($module->overview); ?></p>

                <div class="row mt-auto">
                    <div class="d-flex">
                        <!--[if BLOCK]><![endif]--><?php if($module->v_flag): ?>
                        <span class="badge badge-success p-1 mx-1">Visual</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($module->k_flag): ?>
                        <span class="badge badge-info p-1 mx-1">Kinesthetic</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($module->a_flag): ?>
                        <span class="badge badge-danger p-1 mx-1">Auditory</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($module->r_flag): ?>
                        <span class="badge badge-dark p-1 mx-1">Reading and Writing</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

            </div>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-lg-12">
        <p>No Data</p>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php echo e($modules->links()); ?>



        <?php
        $__scriptKey = '3145724740-0';
        ob_start();
    ?>
    <script>
        $wire.on('show-modal', (data)=> {
            $('#modal').modal('show')
        })
        $wire.on('show-delete-modal', (data)=> {
            $('#delete_modal').modal('show')
        })
    </script>

        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

</div><?php /**PATH C:\Users\Administrator\Desktop\LearningManagementSystem\resources\views/livewire/components/modules-card.blade.php ENDPATH**/ ?>