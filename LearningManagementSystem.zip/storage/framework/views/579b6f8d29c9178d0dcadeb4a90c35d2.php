<div class="container-fluid p-0">
    <div class="row no-gutters h-100">
        <div class="col-lg-6 p-0"
            style="background: url('https://www.businessinsider.in/photo/53672539/This-is-what-makes-Simplilearn-one-of-the-most-effective-Education-Startups-in-recent-times.jpg'); background-size:cover;">
        </div>

        <div class="col-lg-6 p-0">
            <div class="card" style="min-height: 100vh; padding:10%">
                <div class="card-body mt-5 py-5">
                    <h3 class="text-primary">Learning Management System</h3>
                    <p class="card-description">Welcome! Please fill out the form below to sign up. It only takes a few moments to get started. </p>

                    <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
                    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve(['title' => 'success','message' => ''.e(session('success')).'','type' => 'success'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                    <form class="forms-sample material-form">

                        <div class="d-flex justify-content-between">
                            <div class="form-group">
                                <input type="text" required="required" wire:model="first_name" class="<?php if($errors->has('first_name')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" autocomplete="off">
                                <label for="input" class="control-label">First name</label><i class="bar"></i>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div class="form-group">
                                <input type="text" wire:model="middle_name" class="<?php if($errors->has('middle_name')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" autocomplete="off">
                                <label for="input" class="control-label">Middle name</label><i class="bar"></i>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            </div>

                            <div class="form-group">
                                <input type="text" required="required" class="<?php if($errors->has('last_name')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" wire:model="last_name" autocomplete="off">
                                <label for="input" class="control-label">Last name</label><i class="bar"></i>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            </div>
                        </div>

                        <div class="form-group mt-0">
                            <input type="text" required="required" class="<?php if($errors->has('email')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" wire:model="email" autocomplete="off">
                            <label for="input" class="control-label">Email address</label><i class="bar"></i>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        </div>
                        <div class="form-group">
                            <input type="password" required="required" class="<?php if($errors->has('password')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" wire:model="password" autocomplete="off">
                            <label for="input" class="control-label">Password</label><i class="bar"></i>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        </div>

                        <div class="form-group">
                            <input type="password" required="required" class="<?php if($errors->has('password')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" wire:model="password_confirmation" autocomplete="off">
                            <label for="input" class="control-label">Confirm Password</label><i class="bar"></i>
                        </div>

                        <div class="button-container">
                            <button type="button"
                                class="btn btn-rounded btn-success"
                                wire:click="submit"
                                wire:loading.attr="disabled">
                                <span wire:loading.remove>Sign up</span>
                                <span wire:loading>
                                    <i class="fa fa-spinner fa-spin"></i> Loading...
                                </span>
                            </button>
                        </div>


                        <div style="font-size: small;" class="text-left mt-4 fw-light"> Already have an account? <a href="<?php echo e(route('login')); ?> " wire:navigate class="text-primary">Sign in</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Administrator\Desktop\LearningManagementSystem\resources\views/livewire/forms/registration.blade.php ENDPATH**/ ?>