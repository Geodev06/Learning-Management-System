<div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-labelledby="<?php echo e($id); ?>Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header mb-0">
                <h5 class="modal-title" id="<?php echo e($id); ?>Label"><?php echo e($title ?? 'Modal Title'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e($slot); ?>

            </div>
        
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Desktop\LearningManagementSystem\resources\views/components/modal.blade.php ENDPATH**/ ?>