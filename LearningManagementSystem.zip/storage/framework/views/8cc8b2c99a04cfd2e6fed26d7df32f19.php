<div class="container">
    <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve(['title' => 'Error','message' => ''.e(session('error')).'','type' => 'danger'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="row">
        <div class="col-lg-12 p-2">
            <form class="forms-sample material-form">

                <div class="form-group">
                    <input type="text" required="required" wire:model="title" class="<?php if($errors->has('title')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" autocomplete="off">
                    <label for="input" class="control-label">Title</label><i class="bar"></i>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="form-group">

                    <textarea name="" wire:model="overview" id="" cols="30" rows="3"></textarea>
                    <label for="input" class="control-label">Module Description</label><i class="bar"></i>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['overview'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                </div>

                <div class="form-group">
                    <input type="number" required="required" wire:model="no_of_lessons" class="<?php if($errors->has('no_of_lessons')): ?> text-danger <?php else: ?> text-primary <?php endif; ?>" autocomplete="off">
                    <label for="input" class="control-label">No. of Lessons</label><i class="bar"></i>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['no_of_lessons'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-12"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="col-lg-12">

                    <div class="form-check">
                        <label class="form-check-label text-muted">
                            <input type="checkbox" wire:model="a_flag" class="form-check-input"> Auditory <i class="input-helper"></i>
                        </label>
                    </div>
                    <div class="form-check col">
                        <label class="form-check-label text-muted">
                            <input type="checkbox" wire:model="v_flag" class="form-check-input"> Visual <i class="input-helper"></i>
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label text-muted">
                            <input type="checkbox" wire:model="k_flag" class="form-check-input"> Kinesthetic <i class="input-helper"></i>
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label text-muted">
                            <input type="checkbox" wire:model="r_flag" class="form-check-input"> Reading and Writing <i class="input-helper"></i>
                        </label>
                    </div>
                </div>

                <div class="button-container float-end mx-2">
                    <button type="button"
                        class="btn btn-rounded btn-primary"
                        wire:click="submit('Y')"
                        wire:loading.attr="disabled">
                        <span wire:loading.remove>Post</span>
                        <span wire:loading>
                            <i class="fa fa-spinner fa-spin"></i> Loading...
                        </span>
                    </button>
                </div>

                <div class="button-container float-end mx-2">
                    <button type="button"
                        class="btn btn-rounded btn-primary"
                        wire:click="submit('N')"
                        wire:loading.attr="disabled">
                        <span wire:loading.remove>Save as Draft</span>
                        <span wire:loading>
                            <i class="fa fa-spinner fa-spin"></i> Loading...
                        </span>
                    </button>
                </div>


            </form>
        </div>
    </div>


        <?php
        $__assetKey = '3515901179-0';

        ob_start();
    ?>
    <script src="<?php echo e(asset('assets/js/sweetalert2.all.min.js')); ?>"></script>
        <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;
            \Livewire\store($this)->push('assets', $__output, $__assetKey);
        }
    ?>

        <?php
        $__scriptKey = '3515901179-1';
        ob_start();
    ?>
    <script>
        $wire.on('close_modal', (data) => {

            Swal.fire({
                title: data[0].title,
                text: data[0].message,
                icon: data[0].status
            });

            $('#modal').modal('hide')

          
        })
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div><?php /**PATH C:\Users\Administrator\Desktop\LearningManagementSystem\resources\views/livewire/forms/moduleform.blade.php ENDPATH**/ ?>