<div class="row no-gutters h-100">

    <div class="col-lg-12 p-0">
        <div class="card">
            <div class="card-body">
                <h3 class="text-primary">Pre-Assesment</h3>
                <p class="card-description">Please take a moment to complete this survey. Your feedback is valuable to us and will help improve the system. All responses will remain confidential. </p>

                <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
                <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve(['title' => 'Error','message' => ''.e(session('error')).'','type' => 'danger'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <form class="forms-sample material-form">


                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <hr>
                    <h5><b><?php echo e($question->id); ?>. <?php echo e(ucfirst($question->question)); ?></b></h5>
                    <div class="my-2 mb-4 d-flex align-items-center">

                        <div class="form-check mx-2">
                            <label class="form-check-label text-muted">
                                <input type="checkbox" wire:model="question_<?php echo e($question->id); ?>_<?php echo e($question->question_c1_val); ?>" class="form-check-input"><?php echo e($question->question_c1_label); ?> <i class="input-helper"></i></label>
                        </div>

                        <div class="form-check mx-2">
                            <label class="form-check-label text-muted">
                                <input type="checkbox" wire:model="question_<?php echo e($question->id); ?>_<?php echo e($question->question_c2_val); ?>" class="form-check-input"><?php echo e($question->question_c2_label); ?> <i class="input-helper"></i></label>
                        </div>

                        <div class="form-check mx-2">
                            <label class="form-check-label text-muted">
                                <input type="checkbox" wire:model="question_<?php echo e($question->id); ?>_<?php echo e($question->question_c3_val); ?>" class="form-check-input"> <?php echo e($question->question_c3_label); ?> <i class="input-helper"></i></label>
                        </div>

                        <div class="form-check mx-2">
                            <label class="form-check-label text-muted">
                                <input type="checkbox" wire:model="question_<?php echo e($question->id); ?>_<?php echo e($question->question_c4_val); ?>" class="form-check-input"> <?php echo e($question->question_c4_label); ?> <i class="input-helper"></i></label>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                    <div class="button-container">
                        <button type="button"
                            class="btn btn-rounded btn-primary"
                            wire:click="submit"
                            wire:loading.attr="disabled">
                            <span wire:loading.remove>Submit</span>
                            <span wire:loading>
                                <i class="fa fa-spinner fa-spin"></i> Loading...
                            </span>
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

        <?php
        $__assetKey = '2992263415-0';

        ob_start();
    ?>
    <script src="<?php echo e(asset('assets/js/sweetalert2.all.min.js')); ?>"></script>
        <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;
            \Livewire\store($this)->push('assets', $__output, $__assetKey);
        }
    ?>

        <?php
        $__scriptKey = '2992263415-1';
        ob_start();
    ?>
    <script>
        $wire.on('msg_alert', (data) => {

            Swal.fire({
                title: data[0].title,
                text: data[0].message,
                icon: data[0].status
            }).then(function() {
                window.location.replace('/dashboard');
            });

        })
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div><?php /**PATH C:\Users\Administrator\Desktop\LearningManagementSystem\resources\views/livewire/components/survey-form.blade.php ENDPATH**/ ?>