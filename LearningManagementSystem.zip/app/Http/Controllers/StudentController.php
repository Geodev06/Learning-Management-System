<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function learn()
    {
        return view('pages.learn');
    }
}
